class Hero(
    private var name: String,
    private var species: String,
    private var health: Int,
    private var baseAttack: Int,
    private var baseDefense: Int
) {
    init {
        if (!checkSpecies(species)) species = "Humano"
    }

    constructor(name: String, species: String, health: Int) : this(name, species, health, 0, 0) {
        if (!checkSpecies(species)) this.species = "Humano"
    }

    constructor(name: String) : this(name = name, "", 0, 0, 0)

    private fun checkSpecies(species: String): Boolean {
        val typesSpices = mutableListOf("Humano", "Altmer", "Argoniano", "Bosmer", "Breton", "Khajita", "Nordico")
        return typesSpices.contains(species)
    }

    fun attack(): Float {
        val damage = baseAttack * (((5..20).random()) / 10f)
        return damage
    }

    fun defense(damage: Int): Boolean {
        val defenseAttack = damage - baseDefense
        if (defenseAttack > 0) {
            health -= defenseAttack
            return health > 0
        } else {
            return true
        }
    }

    override fun toString(): String {
        return """|Hero: $name
            |Especie: $species
            |Vida: $health
            |Ataque base: $baseAttack
            |Defensa base: $baseDefense
        """.trimMargin()
    }
}