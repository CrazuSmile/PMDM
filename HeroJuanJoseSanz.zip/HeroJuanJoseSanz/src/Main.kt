//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    val hero = Hero("Jojo", "", 10, 5, 10)
    val hero1 = Hero("Jonathan", "Breton", 20)
    val hero2 = Hero("Joseph")

    println(hero.toString())
    println("El heroe ataca: ${hero.attack()}")
    println("El heroe se defiende: ${hero.defense(20)}")
    println("-------------")
    println(hero1.toString())
    println("El heroe ataca: ${hero1.attack()}")
    println("El heroe se defiende: ${hero1.defense(20)}")
    println("--------------")
    println(hero2.toString())
    println("El heroe ataca: ${hero2.attack()}")
    println("El heroe se defiende: ${hero2.defense(20)}")
}