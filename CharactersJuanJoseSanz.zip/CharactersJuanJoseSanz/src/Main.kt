//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    val character = mutableMapOf(
        "Goku" to "DragonBall"
    )

    var serie: String
    var name: String

    do {
        do {
            try {
                println("Por favor, introduzca un nombre de personaje (Escribe FIN para finalizar): ")
                name = readln()
                if (name == "" || name == " ") println("La name no puede ser vacia.") else break
            } catch (e: IllegalArgumentException) {
                println("Error : ${e.message}")
            } catch (e: Exception){
                println("Error : ${e.message}")
            }
        } while (true)
        if (character.containsKey(name)) {
            for ((key, value) in character) {
                if (key == name) {
                    println("$key de $value")
                }
            }
        } else if (name == "FIN") {
            break
        } else {
            do {
                try {
                    println("¿De que serie es?")
                    serie = readln()
                    if (serie == "" || serie == " ") println("La serie no puede ser vacia.") else break
                } catch (e: IllegalArgumentException) {
                    println("Error : ${e.message}")
                }
            } while (true)

            character[name] = serie
        }

        println(" ")
        showCharacters(character)


    } while (name != "FIN")
}

private fun showCharacters(character: MutableMap<String, String>) {
    for ((key, value) in character) {
        println("$key de $value")
    }
}